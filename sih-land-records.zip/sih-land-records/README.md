# Intelligent Land Record Digitization and Validation System
### SIH Problem Statement 18 — Working MVP

Digitizes handwritten/scanned/printed land records into a searchable,
validated digital database, with a human-in-the-loop review workflow.

---

## 1. Architecture

```
Upload (React) ──> FastAPI /upload ──> stored on disk
                         │
                         ▼
              FastAPI /process endpoint
   ┌─────────────────────────────────────────────┐
   │ 1. OpenCV preprocessing                      │
   │    grayscale → deskew → denoise → contrast   │
   │ 2. Tesseract OCR (text + per-word confidence)│
   │ 3. Regex + fuzzy-match + spaCy NER extraction│
   │ 4. Validation engine                          │
   │    - missing fields                           │
   │    - format sanity checks                     │
   │    - low-confidence flagging                   │
   │    - duplicate detection                       │
   │    - cross-document consistency                │
   └─────────────────────────────────────────────┘
                         │
                         ▼
              SQLite database (land_records.db)
                         │
                         ▼
   React Review UI ──> edit / approve / reject
                         │
                         ▼
        Searchable database + Dashboard stats
```

## 2. Folder Structure

```
sih-land-records/
├── backend/
│   ├── app/
│   │   ├── main.py                  # FastAPI app entrypoint
│   │   ├── database/db.py           # SQLAlchemy engine/session
│   │   ├── models/
│   │   │   ├── models.py            # SQLAlchemy ORM tables
│   │   │   └── schemas.py           # Pydantic request/response models
│   │   ├── routes/
│   │   │   ├── documents.py         # upload + process + fetch
│   │   │   ├── review.py            # human-in-the-loop review
│   │   │   ├── search.py            # search API
│   │   │   └── dashboard.py         # stats API
│   │   ├── services/
│   │   │   ├── preprocessing.py     # OpenCV pipeline
│   │   │   ├── ocr_service.py       # Tesseract OCR
│   │   │   ├── extraction_service.py# regex/fuzzy/NLP field extraction
│   │   │   └── validation_service.py# validation engine
│   │   └── utils/
│   │       ├── file_storage.py      # secure upload storage
│   │       └── pdf_utils.py         # PDF → image conversion
│   ├── requirements.txt
│   └── uploads/                     # created automatically
└── frontend/
    ├── package.json
    ├── public/index.html
    └── src/
        ├── App.js
        ├── index.js / index.css
        ├── services/api.js          # all backend API calls
        └── pages/
            ├── DashboardPage.jsx
            ├── UploadPage.jsx
            ├── ReviewPage.jsx        # queue + detail/edit view
            └── SearchPage.jsx
```

---

## 3. Prerequisites

- **Python 3.10+**
- **Node.js 18+** and npm
- **Tesseract OCR engine** installed on your system (this is separate from
  the `pytesseract` Python package, which is just a wrapper):
  - Ubuntu/Debian: `sudo apt-get install tesseract-ocr`
  - macOS: `brew install tesseract`
  - Windows: install from https://github.com/UB-Mannheim/tesseract/wiki,
    then in `backend/app/services/ocr_service.py` add near the top:
    ```python
    import pytesseract
    pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
    ```

---

## 4. Backend Setup & Run

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt
python -m spacy download en_core_web_sm

uvicorn app.main:app --reload --port 8000
```

- API runs at **http://localhost:8000**
- Interactive Swagger docs (great for testing without the frontend) at
  **http://localhost:8000/docs**
- The SQLite database file `land_records.db` and an `uploads/` folder are
  created automatically on first run.

## 5. Frontend Setup & Run

Open a **second terminal**:

```bash
cd frontend
npm install
npm start
```

- App opens at **http://localhost:3000**
- Make sure the backend (step 4) is already running on port 8000 — the
  frontend calls it directly (see `src/services/api.js`, `API_BASE_URL`).

---

## 6. Demo Walkthrough (for SIH presentation)

1. Go to **Upload Document** → upload a photo/scan of a land record
   (JPG/PNG/PDF). Click "Upload & Process".
2. Watch it run preprocessing → OCR → extraction → validation, then
   land you on the **Review** screen.
3. On the Review screen: see the original image + raw OCR text side by
   side with the extracted fields, each tagged with a confidence badge.
   Low-confidence fields and validation flags (missing data, bad
   formats, possible duplicates, cross-document mismatches) are called
   out explicitly.
4. Correct any wrong field, click **Save Corrections**, then
   **Approve** (or **Reject**).
5. Go to **Search Records** → search by owner name / khasra number /
   village / district to show the searchable digital database.
6. Go to **Dashboard** → show total documents, digitized records,
   pending review count, and recently processed documents.
7. To demonstrate duplicate detection: upload the same document (or one
   with the same Khasra No. + Village) twice — the second one will be
   flagged as a possible duplicate.

---

## 7. API Endpoints Reference

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/documents/upload` | Upload a file |
| POST | `/api/documents/{id}/process` | Run OCR+extraction+validation pipeline |
| GET | `/api/documents/{id}` | Get document metadata |
| GET | `/api/documents/{id}/ocr-text` | Get raw OCR text |
| GET | `/api/documents/{id}/image?preprocessed=true|false` | Serve the image |
| GET | `/api/documents` | List all documents |
| GET | `/api/records/{id}` | Get a land record |
| GET | `/api/records/pending/list` | List records pending review |
| PUT | `/api/records/{id}` | Edit/correct fields |
| POST | `/api/records/{id}/review` | Approve or reject |
| GET | `/api/search?owner_name=&survey_number=&village=&district=` | Search |
| GET | `/api/dashboard/stats` | Dashboard statistics |

---

## 8. Notes on Design Choices (useful for judges' Q&A)

- **SQLite for the MVP**: zero-config, single file, easy to demo. Swapping
  to PostgreSQL only requires changing `DATABASE_URL` in `database/db.py`
  — all queries go through SQLAlchemy, so no other code changes needed.
- **Fuzzy label matching**: real scanned registers often have OCR errors
  even in the field *labels* themselves (e.g. "Owner Name" → "Owner
  Nome"). Beyond plain regex, `extraction_service.py` fuzzy-matches
  mangled labels against known aliases (`difflib`), which meaningfully
  improves recall on low-quality scans.
- **Confidence scoring**: each field's confidence combines Tesseract's
  own per-word OCR confidence with a penalty when a value was found via
  a weaker fallback method (fuzzy label match / NER) instead of an exact
  label. Human-corrected fields are marked 100% confident automatically.
- **Duplicate & consistency checks** run against the whole `land_records`
  table (same Khasra No. + Village = likely duplicate; same Khasra No.
  with a different owner name across records = flagged inconsistency).
- **Handwritten text**: Tesseract's LSTM engine has some tolerance for
  neat handwriting but is fundamentally built for printed text. For a
  production system, this is the natural place to plug in a
  handwriting-specific model (e.g. TrOCR) behind the same
  `ocr_service.py` interface — the rest of the pipeline doesn't need to
  change.

---

## 9. Extending Beyond the MVP

- Add authentication/roles for reviewers (FastAPI has built-in OAuth2 support)
- Multi-page PDF support (loop `pdf_to_images` results through the pipeline)
- Regional language OCR (`lang="eng+hin"` in `ocr_service.py` + the
  corresponding Tesseract language pack)
- Move file storage to S3/cloud storage (only `utils/file_storage.py` changes)
- Batch upload + background job queue (Celery/RQ) for large digitization drives
