"""
OCR service — wraps Tesseract OCR (via pytesseract) to extract text
from preprocessed images, and also computes per-word confidence data
that the extraction/validation stages use later.
"""

import pytesseract
from PIL import Image


def extract_text(image_path: str) -> str:
    """Run OCR and return the full extracted text as a single string."""
    image = Image.open(image_path)
    # --psm 6: assume a uniform block of text (good default for registers/forms)
    # lang='eng': for handwritten Devanagari/regional-script documents, add
    #   the relevant trained language pack (e.g. 'hin') and pass lang='eng+hin'
    text = pytesseract.image_to_string(image, lang="eng", config="--psm 6")
    return text


def extract_text_with_confidence(image_path: str):
    """
    Run OCR and return both the text and word-level confidence data.
    Tesseract gives a confidence score (0-100) per recognized word,
    which we use to flag low-confidence regions for human review.

    Returns:
        full_text (str)
        words (list of dicts): [{"text": "Ramesh", "conf": 91.2}, ...]
        avg_confidence (float)
    """
    image = Image.open(image_path)
    data = pytesseract.image_to_data(
        image, lang="eng", config="--psm 6", output_type=pytesseract.Output.DICT
    )

    words = []
    confidences = []
    # Rebuild text line-by-line (grouped by Tesseract's block/par/line
    # indices) so downstream regex/fuzzy field extraction -- which
    # relies on "one label: value per line" -- still works. Using
    # image_to_data alone (word list) loses line breaks; using
    # image_to_string alone loses per-word confidence. We need both.
    lines = {}
    for i, word in enumerate(data["text"]):
        word = word.strip()
        conf = float(data["conf"][i])
        if word and conf >= 0:  # -1 means no confidence (non-text region)
            words.append({"text": word, "conf": conf})
            confidences.append(conf)
            line_key = (data["block_num"][i], data["par_num"][i], data["line_num"][i])
            lines.setdefault(line_key, []).append(word)

    full_text = "\n".join(" ".join(w) for w in lines.values())
    avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0

    return full_text, words, avg_confidence
