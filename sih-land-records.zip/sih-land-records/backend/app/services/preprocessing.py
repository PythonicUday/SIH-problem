"""
Image preprocessing service using OpenCV.

Goal: take a raw photo/scan of a land record (which may be tilted, noisy,
low-contrast, or unevenly lit) and turn it into a clean black-and-white
image that OCR engines can read accurately.

Pipeline:
  1. Load image
  2. Convert to grayscale
  3. Deskew (fix rotation/tilt)
  4. Denoise
  5. Improve contrast (CLAHE - adaptive histogram equalization)
  6. Binarize / sharpen for final OCR-ready output
"""

import cv2
import numpy as np


def load_image(path: str) -> np.ndarray:
    image = cv2.imread(path)
    if image is None:
        raise ValueError(f"Could not read image at {path}")
    return image


def to_grayscale(image: np.ndarray) -> np.ndarray:
    """Step 1: convert to grayscale (removes color, keeps text shapes)."""
    return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)


def denoise(gray: np.ndarray) -> np.ndarray:
    """Step 2: remove speckle/scan noise while preserving text edges."""
    return cv2.fastNlMeansDenoising(gray, h=15, templateWindowSize=7, searchWindowSize=21)


def improve_contrast(gray: np.ndarray) -> np.ndarray:
    """
    Step 3: CLAHE (Contrast Limited Adaptive Histogram Equalization).
    Works better than plain histogram equalization for documents with
    uneven lighting (common in phone photos of old registers).
    """
    clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))
    return clahe.apply(gray)


def deskew(gray: np.ndarray) -> np.ndarray:
    """
    Step 4: detect and correct rotation/tilt.
    Uses the minAreaRect of all non-background pixels to estimate the
    skew angle, then rotates the image to straighten it.
    """
    # Invert so text is white on black background, which minAreaRect expects
    thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)[1]
    coords = np.column_stack(np.where(thresh > 0))

    if len(coords) < 20:
        # Not enough content detected to safely estimate a skew angle
        return gray

    angle = cv2.minAreaRect(coords)[-1]

    # cv2.minAreaRect returns angles in the range [-90, 0); normalize it
    if angle < -45:
        angle = -(90 + angle)
    else:
        angle = -angle

    # Skip correction for near-zero angles (avoid over-rotating clean scans)
    if abs(angle) < 0.5:
        return gray

    (h, w) = gray.shape[:2]
    center = (w // 2, h // 2)
    rotation_matrix = cv2.getRotationMatrix2D(center, angle, 1.0)
    rotated = cv2.warpAffine(
        gray, rotation_matrix, (w, h),
        flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE
    )
    return rotated


def binarize_and_sharpen(gray: np.ndarray) -> np.ndarray:
    """
    Step 5: adaptive thresholding to get crisp black text on white
    background (handles uneven lighting better than a single global
    threshold), then a light sharpening pass.
    """
    binary = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY,
        blockSize=31, C=15
    )
    kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
    sharpened = cv2.filter2D(binary, -1, kernel)
    return sharpened


def preprocess_image(input_path: str, output_path: str) -> str:
    """
    Run the full preprocessing pipeline on a single image and save
    the cleaned result. Returns the output path.
    """
    image = load_image(input_path)
    gray = to_grayscale(image)
    gray = deskew(gray)
    gray = denoise(gray)
    gray = improve_contrast(gray)
    final = binarize_and_sharpen(gray)

    cv2.imwrite(output_path, final)
    return output_path
