"""
Validation engine.

Runs a set of checks over a freshly-extracted land record and produces:
  - a list of human-readable validation error/warning strings
  - an overall confidence score (0-100)
  - duplicate detection against existing approved records in the DB

Checks implemented:
  1. Missing-field check       -> required fields that are None
  2. Format/sanity checks      -> obviously invalid values (e.g. bad date,
                                   non-numeric area, junk-length strings)
  3. Low-confidence flagging   -> any field below CONFIDENCE_THRESHOLD is
                                   marked "Needs Human Verification"
  4. Duplicate detection       -> same survey/khasra number + village
                                   already exists in the DB
  5. Cross-document consistency-> if the same survey number appears with
                                   a different owner name elsewhere, flag it
"""

import re
from datetime import datetime
from typing import Dict, List, Tuple
from sqlalchemy.orm import Session

from app.models.models import LandRecord

CONFIDENCE_THRESHOLD = 65.0   # below this, a field needs human review
REQUIRED_FIELDS = [
    "owner_name", "survey_number", "village", "district", "state"
]


def _is_valid_date(value: str) -> bool:
    for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%d/%m/%y"):
        try:
            datetime.strptime(value, fmt)
            return True
        except ValueError:
            continue
    return False


def _is_valid_area(value: str) -> bool:
    return bool(re.match(r"^[0-9]+(\.[0-9]+)?\s*(acre|hectare|sq\.?\s?ft|sqft|sq\.?\s?m|bigha|gunta)s?$", value, re.IGNORECASE))


def check_missing_fields(fields: Dict) -> List[str]:
    errors = []
    for field in REQUIRED_FIELDS:
        if not fields.get(field):
            errors.append(f"Missing required field: {field.replace('_', ' ').title()}")
    return errors


def check_format_sanity(fields: Dict) -> List[str]:
    errors = []

    if fields.get("record_date") and not _is_valid_date(fields["record_date"]):
        errors.append(f"Date '{fields['record_date']}' does not look like a valid date")

    if fields.get("land_area") and not _is_valid_area(fields["land_area"]):
        errors.append(f"Land area '{fields['land_area']}' is not in a recognized format (e.g. '2.5 Acre')")

    if fields.get("owner_name") and len(fields["owner_name"]) < 3:
        errors.append("Owner name looks too short to be valid")

    if fields.get("survey_number") and not re.match(r"^[A-Za-z0-9\/\-\.]+$", fields["survey_number"]):
        errors.append("Survey/Khasra number contains unexpected characters")

    return errors


def check_low_confidence(fields: Dict, confidence: Dict) -> List[str]:
    errors = []
    for field, value in fields.items():
        if value and confidence.get(field, 0) < CONFIDENCE_THRESHOLD:
            errors.append(
                f"{field.replace('_', ' ').title()} has low OCR confidence "
                f"({confidence.get(field, 0)}%) - Needs Human Verification"
            )
    return errors


def check_duplicate(db: Session, fields: Dict, exclude_id: int = None) -> Tuple[bool, int]:
    """
    A record is considered a likely duplicate if the same survey/khasra
    number AND village already exist among previously approved records.
    Returns (is_duplicate, duplicate_of_id).
    """
    if not fields.get("survey_number") or not fields.get("village"):
        return False, None

    query = db.query(LandRecord).filter(
        LandRecord.survey_number == fields["survey_number"],
        LandRecord.village == fields["village"],
    )
    if exclude_id:
        query = query.filter(LandRecord.id != exclude_id)

    existing = query.first()
    if existing:
        return True, existing.id
    return False, None


def check_cross_document_consistency(db: Session, fields: Dict, exclude_id: int = None) -> List[str]:
    """
    Flags cases where the same survey/khasra number appears in another
    record but with a different owner name -- a common real-world issue
    (ownership disputes, transcription errors, or genuine mutations that
    weren't properly recorded).
    """
    errors = []
    if not fields.get("survey_number") or not fields.get("owner_name"):
        return errors

    query = db.query(LandRecord).filter(LandRecord.survey_number == fields["survey_number"])
    if exclude_id:
        query = query.filter(LandRecord.id != exclude_id)

    for record in query.all():
        if record.owner_name and record.owner_name.strip().lower() != fields["owner_name"].strip().lower():
            errors.append(
                f"Inconsistency: Survey/Khasra No. {fields['survey_number']} is also recorded "
                f"under a different owner name ('{record.owner_name}') in record #{record.id}"
            )
    return errors


def compute_overall_confidence(confidence: Dict, num_errors: int) -> float:
    """
    Weighted score: average of per-field confidences, penalized for
    every validation error found (so a record full of valid, confident
    fields but with 1 duplicate flag still scores lower).
    """
    values = [v for v in confidence.values() if v is not None]
    base = sum(values) / len(values) if values else 0.0
    penalty = min(num_errors * 5, 40)  # cap penalty so it doesn't go absurd
    return round(max(base - penalty, 0.0), 1)


def validate_record(db: Session, fields: Dict, confidence: Dict, exclude_id: int = None) -> Dict:
    """
    Run the full validation suite and return a summary dict:
    {
        "errors": [...],
        "overall_confidence": float,
        "is_duplicate": bool,
        "duplicate_of_id": int | None
    }
    """
    errors = []
    errors += check_missing_fields(fields)
    errors += check_format_sanity(fields)
    errors += check_low_confidence(fields, confidence)

    is_duplicate, duplicate_of_id = check_duplicate(db, fields, exclude_id)
    if is_duplicate:
        errors.append(f"Possible duplicate of existing record #{duplicate_of_id}")

    errors += check_cross_document_consistency(db, fields, exclude_id)

    overall_confidence = compute_overall_confidence(confidence, len(errors))

    return {
        "errors": errors,
        "overall_confidence": overall_confidence,
        "is_duplicate": is_duplicate,
        "duplicate_of_id": duplicate_of_id,
    }
