"""
Land record field extraction service.

Strategy (deliberately simple + explainable for a hackathon demo, but
effective on real registers which are semi-structured "Label: Value"
documents):

  1. Regex patterns per field, tolerant of common OCR misreads and label
     variants (e.g. "Khasra No", "Khasra Number", "Survey No.").
  2. spaCy NER as a fallback/cross-check for person names (Owner /
     Father's name) when the label-based regex misses.
  3. Per-field confidence score computed by combining:
       - how confidently Tesseract recognized the words in that value
         (from the OCR word-confidence list), and
       - a small penalty if the field was found via fallback NLP
         rather than an explicit label match (less certain).
  4. Any field that could not be found at all is left as None with
     confidence 0, so the validation engine can flag it as missing.
"""

import re
import difflib
from typing import Dict, List, Optional, Tuple

try:
    import spacy
    _nlp = spacy.load("en_core_web_sm")
except Exception:
    # If the spaCy model isn't downloaded yet, extraction still works
    # via regex alone -- NER is just a helpful bonus, not a hard dependency.
    _nlp = None


# Each field maps to a list of regex patterns (tried in order).
# (?i) case-insensitive. We capture everything up to a newline / next
# likely label / end of string.
FIELD_PATTERNS: Dict[str, List[str]] = {
    "owner_name": [
        r"owner['’]?s?\s*name\s*[:\-]\s*([A-Za-z\.\s]{3,60})",
        r"name of owner\s*[:\-]\s*([A-Za-z\.\s]{3,60})",
    ],
    "father_husband_name": [
        r"father['’]?s?\s*/?\s*husband['’]?s?\s*name\s*[:\-]\s*([A-Za-z\.\s]{3,60})",
        r"father['’]?s?\s*name\s*[:\-]\s*([A-Za-z\.\s]{3,60})",
        r"s/o\s*[:\-]?\s*([A-Za-z\.\s]{3,60})",
        r"husband['’]?s?\s*name\s*[:\-]\s*([A-Za-z\.\s]{3,60})",
    ],
    "survey_number": [
        r"khasra\s*(?:no|number|num)?\.?\s*[:\-]\s*([A-Za-z0-9\/\-\.]{1,20})",
        r"survey\s*(?:no|number|num)?\.?\s*[:\-]\s*([A-Za-z0-9\/\-\.]{1,20})",
    ],
    "plot_number": [
        r"plot\s*(?:no|number|num)?\.?\s*[:\-]\s*([A-Za-z0-9\/\-\.]{1,20})",
    ],
    "village": [
        r"village\s*(?:name)?\s*[:\-]\s*([A-Za-z\.\s]{2,50})",
        r"gram(?:\s*panchayat)?\s*[:\-]\s*([A-Za-z\.\s]{2,50})",
    ],
    "tehsil": [
        r"tehsil\s*[:\-]\s*([A-Za-z\.\s]{2,50})",
        r"taluka\s*[:\-]\s*([A-Za-z\.\s]{2,50})",
    ],
    "district": [
        r"district\s*[:\-]\s*([A-Za-z\.\s]{2,50})",
    ],
    "state": [
        r"state\s*[:\-]\s*([A-Za-z\.\s]{2,50})",
    ],
    "land_area": [
        r"(?:land\s*)?area\s*[:\-]\s*([0-9\.]+\s*(?:acre|hectare|sq\.?\s?ft|sqft|sq\.?\s?m|bigha|gunta)s?)",
    ],
    "land_type": [
        r"land\s*type\s*[:\-]\s*([A-Za-z\s]{3,30})",
        r"type of land\s*[:\-]\s*([A-Za-z\s]{3,30})",
    ],
    "mutation_number": [
        r"mutation\s*(?:no|number|num)?\.?\s*[:\-]\s*([A-Za-z0-9\/\-]{1,25})",
    ],
    "record_date": [
        r"date\s*[:\-]\s*([0-9]{1,2}[\/\-\.][0-9]{1,2}[\/\-\.][0-9]{2,4})",
        r"dated\s*[:\-]?\s*([0-9]{1,2}[\/\-\.][0-9]{1,2}[\/\-\.][0-9]{2,4})",
    ],
}


# Canonical label phrases per field, used for FUZZY matching when the
# regex patterns above fail -- this is what makes extraction resilient
# to poor-quality scans where Tesseract mangles the label itself
# (e.g. "Owner Name" -> "Owner Nome", "Khasra No" -> "Kasra No").
LABEL_ALIASES: Dict[str, List[str]] = {
    "owner_name": ["owner name", "name of owner", "owners name"],
    "father_husband_name": ["fathers name", "father husband name", "husbands name", "s o"],
    "survey_number": ["khasra no", "khasra number", "survey no", "survey number"],
    "plot_number": ["plot no", "plot number"],
    "village": ["village", "village name", "gram"],
    "tehsil": ["tehsil", "taluka"],
    "district": ["district"],
    "state": ["state"],
    "land_area": ["area", "land area"],
    "land_type": ["land type", "type of land"],
    "mutation_number": ["mutation no", "mutation number"],
    "record_date": ["date", "dated"],
}

_FUZZY_MATCH_THRESHOLD = 0.6


def _normalize_label(text: str) -> str:
    """Lowercase and strip punctuation so OCR noise doesn't block matching."""
    return re.sub(r"[^a-z\s]", "", text.lower()).strip()


def _fuzzy_label_match(label_part: str) -> Optional[Tuple[str, float]]:
    """
    Compare an OCR'd line label against every field's known label
    aliases. Returns (field_name, similarity_ratio) for the best match
    above the threshold, or None if nothing matches well enough.
    """
    normalized = _normalize_label(label_part)
    if not normalized:
        return None

    best_field, best_ratio = None, 0.0
    for field, aliases in LABEL_ALIASES.items():
        for alias in aliases:
            ratio = difflib.SequenceMatcher(None, normalized, alias).ratio()
            if ratio > best_ratio:
                best_field, best_ratio = field, ratio

    if best_ratio >= _FUZZY_MATCH_THRESHOLD:
        return best_field, best_ratio
    return None


def _fuzzy_extract_fields(text: str) -> Dict[str, Tuple[str, float]]:
    """
    Line-by-line fallback extraction for OCR text where labels
    themselves are noisy. Splits each line on the first ':' or '-'
    into (label_part, value_part), fuzzy-matches the label, and
    records the value along with the match ratio (used later to
    scale confidence down for uncertain matches).

    Returns: {field: (value, match_ratio)}
    """
    results: Dict[str, Tuple[str, float]] = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or len(line) < 4:
            continue
        split = re.split(r"[:\-]", line, maxsplit=1)
        if len(split) != 2:
            continue
        label_part, value_part = split
        value_part = _clean_value(value_part)
        if not value_part:
            continue

        match = _fuzzy_label_match(label_part)
        if match:
            field, ratio = match
            # Keep the best-ratio match if a field is found more than once
            if field not in results or ratio > results[field][1]:
                results[field] = (value_part, ratio)
    return results


def _clean_value(value: str) -> str:
    """Trim OCR line-noise / trailing junk off a captured field value."""
    value = value.strip()
    # Cut off at the next obvious label if the regex over-captured
    value = re.split(r"\s{2,}|[\r\n]", value)[0]
    value = value.strip(" .:-")
    return value


def _word_confidence_for_value(value: str, ocr_words: List[dict]) -> float:
    """
    Estimate a field's OCR confidence by averaging the Tesseract
    confidence of the OCR words that appear inside the extracted value.
    Falls back to 60.0 (medium confidence) if no overlapping words are
    found, which can happen after cleanup/regex reshaping.
    """
    if not ocr_words:
        return 60.0

    value_tokens = set(re.findall(r"[A-Za-z0-9]+", value.lower()))
    if not value_tokens:
        return 60.0

    matched_confidences = [
        w["conf"] for w in ocr_words
        if re.sub(r"[^A-Za-z0-9]", "", w["text"]).lower() in value_tokens
    ]
    if not matched_confidences:
        return 60.0

    return round(sum(matched_confidences) / len(matched_confidences), 1)


def _extract_field(field: str, text: str) -> Optional[str]:
    for pattern in FIELD_PATTERNS[field]:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            value = _clean_value(match.group(1))
            if value:
                return value
    return None


def _ner_fallback_names(text: str) -> List[str]:
    """Use spaCy NER to find PERSON entities as a fallback for names."""
    if _nlp is None:
        return []
    doc = _nlp(text)
    return [ent.text.strip() for ent in doc.ents if ent.label_ == "PERSON"]


def extract_fields(raw_text: str, ocr_words: List[dict]) -> Tuple[Dict[str, Optional[str]], Dict[str, float]]:
    """
    Main entry point: given OCR text (+ word confidence list), extract
    all land record fields and a confidence score (0-100) per field.

    Returns: (fields_dict, confidence_dict)
    """
    fields: Dict[str, Optional[str]] = {}
    confidence: Dict[str, float] = {}

    for field in FIELD_PATTERNS:
        value = _extract_field(field, raw_text)
        if value:
            fields[field] = value
            confidence[field] = _word_confidence_for_value(value, ocr_words)
        else:
            fields[field] = None
            confidence[field] = 0.0

    # Fuzzy fallback: for any field the strict regex missed, try
    # matching against noisy/misread labels line-by-line.
    fuzzy_results = _fuzzy_extract_fields(raw_text)
    for field, (value, ratio) in fuzzy_results.items():
        if not fields.get(field) and value:
            fields[field] = value
            base_conf = _word_confidence_for_value(value, ocr_words)
            # Scale confidence down by how uncertain the label match was,
            # since this value wasn't confirmed by an exact label.
            confidence[field] = round(base_conf * ratio, 1)

    # NLP fallback: if owner_name wasn't found via label regex, try NER.
    if not fields.get("owner_name"):
        names = _ner_fallback_names(raw_text)
        if names:
            fields["owner_name"] = names[0]
            # Fallback matches get a modest confidence penalty since
            # they weren't confirmed by an explicit "Owner Name:" label.
            confidence["owner_name"] = max(
                _word_confidence_for_value(names[0], ocr_words) - 15, 0
            )
            if len(names) > 1 and not fields.get("father_husband_name"):
                fields["father_husband_name"] = names[1]
                confidence["father_husband_name"] = max(
                    _word_confidence_for_value(names[1], ocr_words) - 15, 0
                )

    return fields, confidence
