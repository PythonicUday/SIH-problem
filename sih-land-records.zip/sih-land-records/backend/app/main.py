"""
Main FastAPI application entrypoint.

Run with:
    uvicorn app.main:app --reload --port 8000

Then open http://localhost:8000/docs for interactive Swagger API docs.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database.db import Base, engine
from app.models import models  # noqa: F401 - ensures models are registered before create_all
from app.routes import documents, review, search, dashboard

# Create all database tables on startup (SQLite file: land_records.db)
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Intelligent Land Record Digitization and Validation System",
    description="SIH Problem Statement 18 - MVP backend",
    version="1.0.0",
)

# Allow the React frontend (running on a different port) to call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # for hackathon demo simplicity; restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(documents.router)
app.include_router(review.router)
app.include_router(search.router)
app.include_router(dashboard.router)


@app.get("/")
def root():
    return {
        "message": "Land Record Digitization System API is running",
        "docs": "/docs",
    }


@app.get("/api/health")
def health_check():
    return {"status": "ok"}
