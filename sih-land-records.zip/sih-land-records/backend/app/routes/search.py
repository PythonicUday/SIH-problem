"""
Search routes: find digitized land records by owner, survey/khasra
number, village, or district. Supports combining filters and simple
partial (case-insensitive) matching, since real-world names/spellings
vary (e.g. "Ramesh Kumar" vs "Ramesh Kumar Sharma").
"""

from typing import Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.database.db import get_db
from app.models.models import LandRecord
from app.models.schemas import LandRecordOut

router = APIRouter(prefix="/api/search", tags=["Search"])


@router.get("", response_model=list[LandRecordOut])
def search_records(
    owner_name: Optional[str] = Query(None),
    survey_number: Optional[str] = Query(None),
    village: Optional[str] = Query(None),
    district: Optional[str] = Query(None),
    review_status: Optional[str] = Query(None, description="pending_review | approved | rejected"),
    db: Session = Depends(get_db),
):
    query = db.query(LandRecord)

    if owner_name:
        query = query.filter(LandRecord.owner_name.ilike(f"%{owner_name}%"))
    if survey_number:
        query = query.filter(LandRecord.survey_number.ilike(f"%{survey_number}%"))
    if village:
        query = query.filter(LandRecord.village.ilike(f"%{village}%"))
    if district:
        query = query.filter(LandRecord.district.ilike(f"%{district}%"))
    if review_status:
        query = query.filter(LandRecord.review_status == review_status)

    return query.order_by(LandRecord.created_at.desc()).limit(200).all()
