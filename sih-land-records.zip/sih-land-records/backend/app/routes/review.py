"""
Review routes: view, edit, approve/reject digitized land records.
This is the "human-in-the-loop" part of the system -- an admin looks
at the original document + extracted fields side-by-side, corrects
anything wrong, and approves or rejects the record.
"""

from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session

from app.database.db import get_db
from app.models.models import LandRecord, ReviewStatus
from app.models.schemas import LandRecordOut, LandRecordUpdate, ReviewDecision
from app.services.validation_service import validate_record

router = APIRouter(prefix="/api/records", tags=["Review"])


@router.get("/{record_id}", response_model=LandRecordOut)
def get_record(record_id: int, db: Session = Depends(get_db)):
    record = db.query(LandRecord).filter(LandRecord.id == record_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Record not found")
    return record


@router.get("/pending/list", response_model=list[LandRecordOut])
def list_pending_records(db: Session = Depends(get_db)):
    """All records currently awaiting human review."""
    return (
        db.query(LandRecord)
        .filter(LandRecord.review_status == ReviewStatus.PENDING_REVIEW)
        .order_by(LandRecord.created_at.desc())
        .all()
    )


@router.put("/{record_id}", response_model=LandRecordOut)
def update_record(record_id: int, updates: LandRecordUpdate, db: Session = Depends(get_db)):
    """
    Admin edits/corrects one or more fields. Any field the admin
    explicitly sets is treated as human-verified -> confidence 100.
    Re-runs validation afterwards so error flags reflect the corrections.
    """
    record = db.query(LandRecord).filter(LandRecord.id == record_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Record not found")

    update_data = updates.model_dump(exclude_unset=True, exclude={"review_notes"})
    confidence_scores = dict(record.confidence_scores or {})

    for field, value in update_data.items():
        setattr(record, field, value)
        confidence_scores[field] = 100.0  # human-corrected = fully trusted

    record.confidence_scores = confidence_scores

    if updates.review_notes is not None:
        record.review_notes = updates.review_notes

    # Re-validate with the corrected fields
    fields = {
        "owner_name": record.owner_name,
        "father_husband_name": record.father_husband_name,
        "survey_number": record.survey_number,
        "plot_number": record.plot_number,
        "village": record.village,
        "tehsil": record.tehsil,
        "district": record.district,
        "state": record.state,
        "land_area": record.land_area,
        "land_type": record.land_type,
        "mutation_number": record.mutation_number,
        "record_date": record.record_date,
    }
    validation = validate_record(db, fields, confidence_scores, exclude_id=record.id)
    record.validation_errors = validation["errors"]
    record.overall_confidence = validation["overall_confidence"]
    record.is_duplicate = 1 if validation["is_duplicate"] else 0
    record.duplicate_of_id = validation["duplicate_of_id"]

    db.commit()
    db.refresh(record)
    return record


@router.post("/{record_id}/review", response_model=LandRecordOut)
def review_record(record_id: int, decision: ReviewDecision, db: Session = Depends(get_db)):
    """Approve or reject a record after human review."""
    record = db.query(LandRecord).filter(LandRecord.id == record_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Record not found")

    if decision.decision not in ("approve", "reject"):
        raise HTTPException(status_code=400, detail="decision must be 'approve' or 'reject'")

    record.review_status = ReviewStatus.APPROVED if decision.decision == "approve" else ReviewStatus.REJECTED
    record.reviewed_by = decision.reviewed_by
    if decision.review_notes:
        record.review_notes = decision.review_notes

    db.commit()
    db.refresh(record)
    return record
