"""
Dashboard routes: aggregate stats for the admin dashboard UI.
"""

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.database.db import get_db
from app.models.models import Document, LandRecord, ReviewStatus
from app.models.schemas import DashboardStats

router = APIRouter(prefix="/api/dashboard", tags=["Dashboard"])


@router.get("/stats", response_model=DashboardStats)
def get_dashboard_stats(db: Session = Depends(get_db)):
    total_documents = db.query(func.count(Document.id)).scalar() or 0
    records_digitized = db.query(func.count(LandRecord.id)).scalar() or 0

    records_pending_review = (
        db.query(func.count(LandRecord.id))
        .filter(LandRecord.review_status == ReviewStatus.PENDING_REVIEW)
        .scalar() or 0
    )
    records_approved = (
        db.query(func.count(LandRecord.id))
        .filter(LandRecord.review_status == ReviewStatus.APPROVED)
        .scalar() or 0
    )
    records_rejected = (
        db.query(func.count(LandRecord.id))
        .filter(LandRecord.review_status == ReviewStatus.REJECTED)
        .scalar() or 0
    )

    # Count records that have at least one validation error/flag
    all_records = db.query(LandRecord).all()
    validation_errors_count = sum(
        1 for r in all_records if r.validation_errors and len(r.validation_errors) > 0
    )

    recent_documents = (
        db.query(Document).order_by(Document.upload_time.desc()).limit(10).all()
    )

    return DashboardStats(
        total_documents=total_documents,
        records_digitized=records_digitized,
        records_pending_review=records_pending_review,
        records_approved=records_approved,
        records_rejected=records_rejected,
        validation_errors_count=validation_errors_count,
        recent_documents=recent_documents,
    )
