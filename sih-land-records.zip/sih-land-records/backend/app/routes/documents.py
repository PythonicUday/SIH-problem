"""
Document routes: upload a file, and run it through the
preprocess -> OCR -> extract -> validate pipeline.
"""

import os
from fastapi import APIRouter, UploadFile, File, HTTPException, Depends
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.database.db import get_db
from app.models.models import Document, LandRecord, DocumentStatus
from app.models.schemas import DocumentOut, LandRecordOut
from app.utils.file_storage import save_upload, validate_extension, PREPROCESSED_DIR, UPLOAD_DIR
from app.utils.pdf_utils import pdf_to_images
from app.services.preprocessing import preprocess_image
from app.services.ocr_service import extract_text_with_confidence
from app.services.extraction_service import extract_fields
from app.services.validation_service import validate_record

router = APIRouter(prefix="/api/documents", tags=["Documents"])


@router.post("/upload", response_model=DocumentOut)
async def upload_document(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """Step 1: accept and securely store an uploaded image or PDF."""
    try:
        ext = validate_extension(file.filename)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    file_bytes = await file.read()
    if len(file_bytes) == 0:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")

    stored_path = save_upload(file_bytes, file.filename)

    document = Document(
        filename=file.filename,
        stored_path=stored_path,
        file_type=ext.replace(".", ""),
        status=DocumentStatus.UPLOADED,
    )
    db.add(document)
    db.commit()
    db.refresh(document)
    return document


@router.post("/{document_id}/process", response_model=LandRecordOut)
def process_document(document_id: int, db: Session = Depends(get_db)):
    """
    Runs the full pipeline on an uploaded document:
      1. Preprocess image(s) with OpenCV (grayscale, deskew, denoise, contrast)
      2. OCR with Tesseract
      3. Extract structured fields (regex + NLP)
      4. Validate + score confidence + detect duplicates
      5. Save a LandRecord row pending human review
    For PDFs, only the first page is processed in this MVP (each page
    could be looped over the same way for multi-page registers).
    """
    document = db.query(Document).filter(Document.id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")

    try:
        document.status = DocumentStatus.PREPROCESSING

        # If PDF, convert first page to an image first
        if document.file_type == "pdf":
            page_images = pdf_to_images(document.stored_path, os.path.join(UPLOAD_DIR, "pdf_pages"))
            if not page_images:
                raise HTTPException(status_code=400, detail="Could not extract any pages from PDF")
            source_image_path = page_images[0]
        else:
            source_image_path = document.stored_path

        # --- Step 2: OpenCV preprocessing ---
        preprocessed_path = os.path.join(PREPROCESSED_DIR, f"{document.id}_preprocessed.png")
        preprocess_image(source_image_path, preprocessed_path)
        document.preprocessed_path = preprocessed_path

        # --- Step 3: OCR ---
        raw_text, ocr_words, avg_ocr_conf = extract_text_with_confidence(preprocessed_path)
        document.raw_ocr_text = raw_text
        document.status = DocumentStatus.OCR_DONE

        # --- Step 4: Field extraction ---
        fields, confidence = extract_fields(raw_text, ocr_words)
        document.status = DocumentStatus.EXTRACTED

        # --- Step 5: Validation ---
        validation = validate_record(db, fields, confidence)
        document.status = DocumentStatus.VALIDATED

        record = LandRecord(
            document_id=document.id,
            owner_name=fields.get("owner_name"),
            father_husband_name=fields.get("father_husband_name"),
            survey_number=fields.get("survey_number"),
            plot_number=fields.get("plot_number"),
            village=fields.get("village"),
            tehsil=fields.get("tehsil"),
            district=fields.get("district"),
            state=fields.get("state"),
            land_area=fields.get("land_area"),
            land_type=fields.get("land_type"),
            mutation_number=fields.get("mutation_number"),
            record_date=fields.get("record_date"),
            confidence_scores=confidence,
            validation_errors=validation["errors"],
            overall_confidence=validation["overall_confidence"],
            is_duplicate=1 if validation["is_duplicate"] else 0,
            duplicate_of_id=validation["duplicate_of_id"],
        )
        db.add(record)
        db.commit()
        db.refresh(document)
        db.refresh(record)
        return record

    except HTTPException:
        raise
    except Exception as e:
        document.status = DocumentStatus.FAILED
        db.commit()
        raise HTTPException(status_code=500, detail=f"Processing failed: {str(e)}")


@router.get("/{document_id}", response_model=DocumentOut)
def get_document(document_id: int, db: Session = Depends(get_db)):
    document = db.query(Document).filter(Document.id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    return document


@router.get("/{document_id}/ocr-text")
def get_ocr_text(document_id: int, db: Session = Depends(get_db)):
    """Returns the raw OCR text for a document (for the review screen)."""
    document = db.query(Document).filter(Document.id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    return {"document_id": document.id, "raw_ocr_text": document.raw_ocr_text}


@router.get("/{document_id}/image")
def get_document_image(document_id: int, preprocessed: bool = False, db: Session = Depends(get_db)):
    """Serves the original or preprocessed image so the review UI can display it."""
    document = db.query(Document).filter(Document.id == document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")

    path = document.preprocessed_path if preprocessed else document.stored_path
    if not path or not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Image file not found")
    return FileResponse(path)


@router.get("", response_model=list[DocumentOut])
def list_documents(db: Session = Depends(get_db)):
    return db.query(Document).order_by(Document.upload_time.desc()).all()
