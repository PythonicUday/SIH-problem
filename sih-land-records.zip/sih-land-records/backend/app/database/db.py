"""
Database connection setup.

We use SQLite for the MVP (zero-config, single file, perfect for a hackathon demo).
Swapping to PostgreSQL later only requires changing DATABASE_URL below -
the rest of the code (SQLAlchemy models/queries) stays the same.
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# SQLite database file will be created at backend/land_records.db
DATABASE_URL = "sqlite:///./land_records.db"

# check_same_thread=False is required for SQLite when used with FastAPI's
# multi-threaded request handling.
engine = create_engine(
    DATABASE_URL, connect_args={"check_same_thread": False}
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base class every SQLAlchemy model inherits from
Base = declarative_base()


def get_db():
    """
    FastAPI dependency that provides a database session per-request
    and always closes it afterwards, even if an error occurs.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
