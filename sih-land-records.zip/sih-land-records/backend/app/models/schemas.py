"""
Pydantic schemas — define the shape of data going in/out of the API.
Kept separate from the SQLAlchemy models (models.py) on purpose:
SQLAlchemy models = database tables, Pydantic schemas = API contracts.
"""

from datetime import datetime
from typing import Optional, List, Dict
from pydantic import BaseModel


class DocumentOut(BaseModel):
    id: int
    filename: str
    file_type: str
    upload_time: datetime
    status: str

    class Config:
        from_attributes = True


class LandRecordUpdate(BaseModel):
    """Fields an admin can edit during human review."""
    owner_name: Optional[str] = None
    father_husband_name: Optional[str] = None
    survey_number: Optional[str] = None
    plot_number: Optional[str] = None
    village: Optional[str] = None
    tehsil: Optional[str] = None
    district: Optional[str] = None
    state: Optional[str] = None
    land_area: Optional[str] = None
    land_type: Optional[str] = None
    mutation_number: Optional[str] = None
    record_date: Optional[str] = None
    review_notes: Optional[str] = None


class ReviewDecision(BaseModel):
    decision: str  # "approve" or "reject"
    reviewed_by: Optional[str] = "admin"
    review_notes: Optional[str] = None


class LandRecordOut(BaseModel):
    id: int
    document_id: int
    owner_name: Optional[str]
    father_husband_name: Optional[str]
    survey_number: Optional[str]
    plot_number: Optional[str]
    village: Optional[str]
    tehsil: Optional[str]
    district: Optional[str]
    state: Optional[str]
    land_area: Optional[str]
    land_type: Optional[str]
    mutation_number: Optional[str]
    record_date: Optional[str]
    confidence_scores: Optional[Dict]
    validation_errors: Optional[List[str]]
    overall_confidence: float
    is_duplicate: int
    duplicate_of_id: Optional[int]
    review_status: str
    reviewed_by: Optional[str]
    review_notes: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


class DashboardStats(BaseModel):
    total_documents: int
    records_digitized: int
    records_pending_review: int
    records_approved: int
    records_rejected: int
    validation_errors_count: int
    recent_documents: List[DocumentOut]
