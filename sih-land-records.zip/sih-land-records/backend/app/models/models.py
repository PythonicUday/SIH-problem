"""
SQLAlchemy ORM models — these define the database tables.

Two main tables:
  1. Document      -> one row per uploaded file (the raw scan/photo/PDF)
  2. LandRecord     -> one row per digitized land record extracted from a
                       document, holding the structured fields + validation
                       + review status.

We keep them separate because in real life one document can sometimes
contain more than one record (e.g. a register page with several entries),
and because it lets the review workflow operate on structured data
without touching the original file.
"""

import enum
from datetime import datetime

from sqlalchemy import (
    Column, Integer, String, Float, DateTime, Text, ForeignKey, Enum, JSON
)
from sqlalchemy.orm import relationship

from app.database.db import Base


class DocumentStatus(str, enum.Enum):
    """Lifecycle of an uploaded document."""
    UPLOADED = "uploaded"
    PREPROCESSING = "preprocessing"
    OCR_DONE = "ocr_done"
    EXTRACTED = "extracted"
    VALIDATED = "validated"
    FAILED = "failed"


class ReviewStatus(str, enum.Enum):
    """Human-in-the-loop review status of a digitized record."""
    PENDING_REVIEW = "pending_review"
    APPROVED = "approved"
    REJECTED = "rejected"


class Document(Base):
    """An uploaded raw file (image or PDF) before/after processing."""
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True, index=True)
    filename = Column(String, nullable=False)          # original filename
    stored_path = Column(String, nullable=False)        # path on disk
    preprocessed_path = Column(String, nullable=True)    # cleaned image path
    file_type = Column(String, nullable=False)           # jpg/png/pdf
    upload_time = Column(DateTime, default=datetime.utcnow)
    status = Column(Enum(DocumentStatus), default=DocumentStatus.UPLOADED)
    raw_ocr_text = Column(Text, nullable=True)            # full OCR dump

    records = relationship("LandRecord", back_populates="document")


class LandRecord(Base):
    """A structured, extracted land record tied back to its source document."""
    __tablename__ = "land_records"

    id = Column(Integer, primary_key=True, index=True)
    document_id = Column(Integer, ForeignKey("documents.id"))

    # --- extracted fields ---
    owner_name = Column(String, nullable=True)
    father_husband_name = Column(String, nullable=True)
    survey_number = Column(String, nullable=True)   # Survey No. / Khasra No.
    plot_number = Column(String, nullable=True)
    village = Column(String, nullable=True)
    tehsil = Column(String, nullable=True)
    district = Column(String, nullable=True)
    state = Column(String, nullable=True)
    land_area = Column(String, nullable=True)
    land_type = Column(String, nullable=True)
    mutation_number = Column(String, nullable=True)
    record_date = Column(String, nullable=True)

    # --- confidence scores per field, stored as JSON: {"owner_name": 92.5, ...}
    confidence_scores = Column(JSON, nullable=True)

    # --- validation ---
    validation_errors = Column(JSON, nullable=True)   # list of issue strings
    overall_confidence = Column(Float, default=0.0)
    is_duplicate = Column(Integer, default=0)          # 0/1 flag
    duplicate_of_id = Column(Integer, nullable=True)

    # --- review workflow ---
    review_status = Column(Enum(ReviewStatus), default=ReviewStatus.PENDING_REVIEW)
    reviewed_by = Column(String, nullable=True)
    review_notes = Column(Text, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    document = relationship("Document", back_populates="records")
