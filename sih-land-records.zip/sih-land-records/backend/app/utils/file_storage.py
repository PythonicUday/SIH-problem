"""
Secure file storage helper for uploaded documents.

For the MVP we store files on local disk under a UUID-based filename
(so the original filename never determines the path -> avoids path
traversal / overwrite attacks, and avoids collisions). In production
this would point at S3 / a cloud object store instead, but the rest of
the app doesn't need to change since it just deals with "stored_path".
"""

import os
import uuid

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "uploads")
PREPROCESSED_DIR = os.path.join(UPLOAD_DIR, "preprocessed")

ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".pdf"}

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(PREPROCESSED_DIR, exist_ok=True)


def validate_extension(filename: str) -> str:
    """Returns the lowercase extension if allowed, else raises ValueError."""
    ext = os.path.splitext(filename)[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise ValueError(
            f"Unsupported file type '{ext}'. Allowed: {', '.join(ALLOWED_EXTENSIONS)}"
        )
    return ext


def save_upload(file_bytes: bytes, original_filename: str) -> str:
    """
    Saves the uploaded file to disk under a random, safe filename.
    Returns the full path where it was stored.
    """
    ext = validate_extension(original_filename)
    safe_name = f"{uuid.uuid4().hex}{ext}"
    stored_path = os.path.join(UPLOAD_DIR, safe_name)

    with open(stored_path, "wb") as f:
        f.write(file_bytes)

    return stored_path
