"""
Utility to convert PDF pages into images so they can go through the
same OpenCV + Tesseract pipeline as JPG/PNG uploads.

Uses PyMuPDF (fitz) because it needs no external system dependency
(unlike pdf2image, which requires poppler to be installed separately) -
this keeps the MVP easy to set up for a hackathon demo.
"""

import fitz  # PyMuPDF
import os


def pdf_to_images(pdf_path: str, output_dir: str, dpi: int = 300) -> list:
    """
    Convert every page of a PDF into a PNG image.
    Returns a list of file paths, one per page, in order.
    """
    os.makedirs(output_dir, exist_ok=True)
    doc = fitz.open(pdf_path)
    zoom = dpi / 72  # PDF default is 72 DPI
    matrix = fitz.Matrix(zoom, zoom)

    image_paths = []
    base_name = os.path.splitext(os.path.basename(pdf_path))[0]

    for page_number in range(len(doc)):
        page = doc[page_number]
        pix = page.get_pixmap(matrix=matrix)
        out_path = os.path.join(output_dir, f"{base_name}_page{page_number + 1}.png")
        pix.save(out_path)
        image_paths.append(out_path)

    doc.close()
    return image_paths
