// Central place for all backend API calls.
// Change API_BASE_URL if the backend runs on a different host/port.
import axios from "axios";

export const API_BASE_URL = "http://localhost:8000";

const api = axios.create({ baseURL: API_BASE_URL });

// ---------- Documents ----------
export const uploadDocument = (file) => {
  const formData = new FormData();
  formData.append("file", file);
  return api.post("/api/documents/upload", formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};

export const processDocument = (documentId) =>
  api.post(`/api/documents/${documentId}/process`);

export const listDocuments = () => api.get("/api/documents");

export const getDocument = (documentId) =>
  api.get(`/api/documents/${documentId}`);

export const getOcrText = (documentId) =>
  api.get(`/api/documents/${documentId}/ocr-text`);

export const getDocumentImageUrl = (documentId, preprocessed = false) =>
  `${API_BASE_URL}/api/documents/${documentId}/image?preprocessed=${preprocessed}`;

// ---------- Review ----------
export const getRecord = (recordId) => api.get(`/api/records/${recordId}`);

export const listPendingRecords = () => api.get("/api/records/pending/list");

export const updateRecord = (recordId, updates) =>
  api.put(`/api/records/${recordId}`, updates);

export const reviewRecord = (recordId, decision, reviewedBy, notes) =>
  api.post(`/api/records/${recordId}/review`, {
    decision,
    reviewed_by: reviewedBy,
    review_notes: notes,
  });

// ---------- Search ----------
export const searchRecords = (params) => api.get("/api/search", { params });

// ---------- Dashboard ----------
export const getDashboardStats = () => api.get("/api/dashboard/stats");

export default api;
