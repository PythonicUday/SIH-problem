import React, { useEffect, useState } from "react";
import { getDashboardStats, getDocumentImageUrl } from "../services/api";

export default function DashboardPage() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState("");

  const load = () => {
    getDashboardStats()
      .then((res) => setStats(res.data))
      .catch(() => setError("Could not reach the backend. Is it running on port 8000?"));
  };

  useEffect(() => {
    load();
    const interval = setInterval(load, 8000); // auto-refresh every 8s
    return () => clearInterval(interval);
  }, []);

  if (error) return <div className="card">{error}</div>;
  if (!stats) return <p className="spinner-text">Loading dashboard...</p>;

  const cards = [
    { label: "Total Documents Uploaded", value: stats.total_documents },
    { label: "Records Digitized", value: stats.records_digitized },
    { label: "Pending Review", value: stats.records_pending_review },
    { label: "Approved", value: stats.records_approved },
    { label: "Rejected", value: stats.records_rejected },
    { label: "Records With Validation Flags", value: stats.validation_errors_count },
  ];

  return (
    <div>
      <h2>Dashboard</h2>
      <div className="stats-grid">
        {cards.map((c) => (
          <div className="stat-card" key={c.label}>
            <div className="stat-value">{c.value}</div>
            <div className="stat-label">{c.label}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <h3>Recently Processed Documents</h3>
        {stats.recent_documents.length === 0 && <p>No documents uploaded yet.</p>}
        <table>
          <thead>
            <tr>
              <th>Preview</th>
              <th>Filename</th>
              <th>Type</th>
              <th>Status</th>
              <th>Uploaded</th>
            </tr>
          </thead>
          <tbody>
            {stats.recent_documents.map((d) => (
              <tr key={d.id}>
                <td>
                  {d.file_type !== "pdf" && (
                    <img
                      src={getDocumentImageUrl(d.id, false)}
                      alt=""
                      style={{ width: 40, height: 40, objectFit: "cover", borderRadius: 4 }}
                      onError={(e) => (e.target.style.display = "none")}
                    />
                  )}
                </td>
                <td>{d.filename}</td>
                <td>{d.file_type.toUpperCase()}</td>
                <td>
                  <span className="badge badge-pending">{d.status}</span>
                </td>
                <td>{new Date(d.upload_time).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
