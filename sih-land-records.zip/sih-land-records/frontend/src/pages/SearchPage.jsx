import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { searchRecords } from "../services/api";

export default function SearchPage() {
  const [filters, setFilters] = useState({
    owner_name: "",
    survey_number: "",
    village: "",
    district: "",
  });
  const [results, setResults] = useState(null);
  const navigate = useNavigate();

  const handleChange = (key, value) => setFilters((prev) => ({ ...prev, [key]: value }));

  const handleSearch = async () => {
    const params = Object.fromEntries(
      Object.entries(filters).filter(([, v]) => v.trim() !== "")
    );
    const res = await searchRecords(params);
    setResults(res.data);
  };

  return (
    <div>
      <h2>Search Land Records</h2>
      <div className="card">
        <div className="search-bar">
          <input
            placeholder="Owner Name"
            value={filters.owner_name}
            onChange={(e) => handleChange("owner_name", e.target.value)}
          />
          <input
            placeholder="Survey / Khasra Number"
            value={filters.survey_number}
            onChange={(e) => handleChange("survey_number", e.target.value)}
          />
          <input
            placeholder="Village"
            value={filters.village}
            onChange={(e) => handleChange("village", e.target.value)}
          />
          <input
            placeholder="District"
            value={filters.district}
            onChange={(e) => handleChange("district", e.target.value)}
          />
          <button className="btn" onClick={handleSearch}>Search</button>
        </div>
      </div>

      {results && (
        <div className="card">
          <h3>{results.length} result(s)</h3>
          <table>
            <thead>
              <tr>
                <th>Owner</th>
                <th>Khasra/Survey No.</th>
                <th>Village</th>
                <th>District</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {results.map((r) => (
                <tr key={r.id}>
                  <td>{r.owner_name || "—"}</td>
                  <td>{r.survey_number || "—"}</td>
                  <td>{r.village || "—"}</td>
                  <td>{r.district || "—"}</td>
                  <td>
                    <span
                      className={`badge badge-${
                        r.review_status === "approved"
                          ? "approved"
                          : r.review_status === "rejected"
                          ? "rejected"
                          : "pending"
                      }`}
                    >
                      {r.review_status}
                    </span>
                  </td>
                  <td>
                    <button className="btn btn-secondary" onClick={() => navigate(`/review/${r.id}`)}>
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
