import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import {
  listPendingRecords,
  getRecord,
  updateRecord,
  reviewRecord,
  getDocumentImageUrl,
  getOcrText,
} from "../services/api";

const FIELD_LABELS = {
  owner_name: "Owner Name",
  father_husband_name: "Father's / Husband's Name",
  survey_number: "Survey / Khasra No.",
  plot_number: "Plot Number",
  village: "Village",
  tehsil: "Tehsil",
  district: "District",
  state: "State",
  land_area: "Land Area",
  land_type: "Land Type",
  mutation_number: "Mutation Number",
  record_date: "Date",
};

function confidenceBadgeClass(score) {
  if (score >= 80) return "badge-confidence-high";
  if (score >= 50) return "badge-confidence-medium";
  return "badge-confidence-low";
}

function ReviewQueue() {
  const [records, setRecords] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    listPendingRecords().then((res) => setRecords(res.data));
  }, []);

  return (
    <div>
      <h2>Review Queue</h2>
      <div className="card">
        {records.length === 0 && <p>No records pending review. Upload a document to get started.</p>}
        {records.map((r) => (
          <div className="doc-queue-item" key={r.id}>
            <div>
              <strong>{r.owner_name || "(owner name not extracted)"}</strong>
              <div style={{ fontSize: 13, color: "#64748b" }}>
                Khasra/Survey: {r.survey_number || "—"} &middot; Village: {r.village || "—"}
              </div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <span className={`badge ${confidenceBadgeClass(r.overall_confidence)}`}>
                {r.overall_confidence}% confidence
              </span>
              {r.validation_errors?.length > 0 && (
                <span className="badge badge-rejected">{r.validation_errors.length} flags</span>
              )}
              <button className="btn btn-secondary" onClick={() => navigate(`/review/${r.id}`)}>
                Review
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function RecordDetail({ recordId }) {
  const [record, setRecord] = useState(null);
  const [ocrText, setOcrText] = useState("");
  const [fields, setFields] = useState({});
  const [saving, setSaving] = useState(false);
  const navigate = useNavigate();

  const load = () => {
    getRecord(recordId).then((res) => {
      setRecord(res.data);
      setFields(
        Object.fromEntries(Object.keys(FIELD_LABELS).map((k) => [k, res.data[k] || ""]))
      );
      getOcrText(res.data.document_id).then((r) => setOcrText(r.data.raw_ocr_text || ""));
    });
  };

  useEffect(load, [recordId]);

  const handleFieldChange = (key, value) => {
    setFields((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateRecord(recordId, fields);
      load();
    } finally {
      setSaving(false);
    }
  };

  const handleDecision = async (decision) => {
    await handleSave();
    await reviewRecord(recordId, decision, "admin");
    navigate("/review");
  };

  if (!record) return <p className="spinner-text">Loading record...</p>;

  return (
    <div>
      <h2>Review Record #{record.id}</h2>
      <div className="review-layout">
        <div className="card">
          <h3>Original Document</h3>
          <img
            src={getDocumentImageUrl(record.document_id, false)}
            alt="original document"
            onError={(e) => (e.target.style.display = "none")}
          />
          <h4 style={{ marginTop: 16 }}>Raw OCR Text</h4>
          <div className="ocr-text-box">{ocrText || "(no text extracted)"}</div>
        </div>

        <div className="card">
          <h3>Extracted Fields</h3>
          {Object.entries(FIELD_LABELS).map(([key, label]) => (
            <div className="field-row" key={key}>
              <label>{label}</label>
              <input
                value={fields[key] || ""}
                onChange={(e) => handleFieldChange(key, e.target.value)}
              />
              {record.confidence_scores?.[key] !== undefined && (
                <span className={`badge ${confidenceBadgeClass(record.confidence_scores[key])}`}>
                  {Math.round(record.confidence_scores[key])}%
                </span>
              )}
            </div>
          ))}

          {record.validation_errors?.length > 0 && (
            <div className="error-list">
              <strong>Validation Flags:</strong>
              <ul>
                {record.validation_errors.map((e, i) => (
                  <li key={i}>{e}</li>
                ))}
              </ul>
            </div>
          )}

          <div style={{ marginTop: 20, display: "flex", gap: 10 }}>
            <button className="btn btn-secondary" onClick={handleSave} disabled={saving}>
              {saving ? "Saving..." : "Save Corrections"}
            </button>
            <button className="btn btn-success" onClick={() => handleDecision("approve")}>
              Approve
            </button>
            <button className="btn btn-danger" onClick={() => handleDecision("reject")}>
              Reject
            </button>
          </div>
        </div>
      </div>
      <p style={{ marginTop: 16 }}>
        <Link to="/review">&larr; Back to Review Queue</Link>
      </p>
    </div>
  );
}

export default function ReviewPage() {
  const { recordId } = useParams();
  return recordId ? <RecordDetail recordId={recordId} /> : <ReviewQueue />;
}
