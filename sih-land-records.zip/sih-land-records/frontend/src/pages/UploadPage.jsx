import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { uploadDocument, processDocument } from "../services/api";

export default function UploadPage() {
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState("");
  const [uploading, setUploading] = useState(false);
  const navigate = useNavigate();

  const handleUpload = async () => {
    if (!file) return;
    setUploading(true);
    setStatus("Uploading file...");
    try {
      const uploadRes = await uploadDocument(file);
      const documentId = uploadRes.data.id;

      setStatus("Running preprocessing + OCR + extraction + validation... (this can take a few seconds)");
      const processRes = await processDocument(documentId);

      setStatus("Done! Redirecting to review screen...");
      setTimeout(() => navigate(`/review/${processRes.data.id}`), 800);
    } catch (err) {
      setStatus(
        "Error: " + (err.response?.data?.detail || err.message)
      );
    } finally {
      setUploading(false);
    }
  };

  return (
    <div>
      <h2>Upload Land Record Document</h2>
      <div className="card">
        <div className="upload-box">
          <p>Upload a scanned image or PDF of a land record</p>
          <input
            type="file"
            accept=".jpg,.jpeg,.png,.pdf"
            onChange={(e) => setFile(e.target.files[0])}
          />
          <p style={{ fontSize: 12, marginTop: 10 }}>Supported: JPG, PNG, JPEG, PDF</p>
        </div>
        <button className="btn" disabled={!file || uploading} onClick={handleUpload}>
          {uploading ? "Processing..." : "Upload & Process"}
        </button>
        {status && <p className="spinner-text" style={{ marginTop: 12 }}>{status}</p>}
      </div>

      <div className="card">
        <h3>What happens when you click "Upload & Process"?</h3>
        <ol style={{ fontSize: 14, color: "#475569" }}>
          <li>File is securely stored on the server</li>
          <li>OpenCV cleans the image: grayscale, deskew, denoise, contrast boost</li>
          <li>Tesseract OCR extracts raw text</li>
          <li>Regex + NLP pull out structured fields (owner, khasra no, village, etc.)</li>
          <li>The validation engine checks for missing/invalid/duplicate data and scores confidence</li>
          <li>You land on the Review screen to verify and approve the record</li>
        </ol>
      </div>
    </div>
  );
}
