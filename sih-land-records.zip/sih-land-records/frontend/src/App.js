import React from "react";
import { HashRouter, Routes, Route, NavLink } from "react-router-dom";
import DashboardPage from "./pages/DashboardPage";
import UploadPage from "./pages/UploadPage";
import ReviewPage from "./pages/ReviewPage";
import SearchPage from "./pages/SearchPage";

function Sidebar() {
  return (
    <div className="sidebar">
      <h1>Bhoomi Digitize</h1>
      <div className="subtitle">SIH PS-18 &middot; Land Record MVP</div>
      <nav>
        <NavLink to="/" end className={({ isActive }) => (isActive ? "active" : "")}>
          Dashboard
        </NavLink>
        <NavLink to="/upload" className={({ isActive }) => (isActive ? "active" : "")}>
          Upload Document
        </NavLink>
        <NavLink to="/review" className={({ isActive }) => (isActive ? "active" : "")}>
          Review Queue
        </NavLink>
        <NavLink to="/search" className={({ isActive }) => (isActive ? "active" : "")}>
          Search Records
        </NavLink>
      </nav>
    </div>
  );
}

export default function App() {
  return (
    <HashRouter>
      <div className="app-shell">
        <Sidebar />
        <div className="main-content">
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/upload" element={<UploadPage />} />
            <Route path="/review" element={<ReviewPage />} />
            <Route path="/review/:recordId" element={<ReviewPage />} />
            <Route path="/search" element={<SearchPage />} />
          </Routes>
        </div>
      </div>
    </HashRouter>
  );
}
